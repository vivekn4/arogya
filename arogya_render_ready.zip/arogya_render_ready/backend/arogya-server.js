import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import Anthropic from "@anthropic-ai/sdk";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));

if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("Missing ANTHROPIC_API_KEY in environment variables.");
}

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const SYSTEM_PROMPT = `You are "Arogya" — a warm, knowledgeable wellness companion. You feel like a caring, calm friend who genuinely wants to help people feel better.

PERSONALITY: Human and natural. Short opener ("Hey!" / "Hi!") then ask what's wrong. Semi-casual, never clinical. Gentle reassurance. Ask ONE question at a time. Keep messages short.

STRUCTURED FLOW:
1. AREA — user selects body area. Acknowledge warmly, ask what they feel there.
2. SYMPTOMS — what specifically are they feeling?
3. DURATION — how long?
4. SEVERITY — mild / moderate / quite bad?
5. REMEDY — give natural home remedy advice.

EDGE CASE HANDLING:
- VAGUE INPUT ("idk","maybe","not sure"): Reframe differently, offer 3-4 specific quick-reply examples. After 2 unclear answers, move forward with best guess and confirm.
- GIBBERISH/TYPOS: "Hmm, I didn't catch that! Could you try again?" with quick-reply options.
- OFF-TOPIC: Warmly redirect to wellness without answering.
- FRUSTRATED USER: Acknowledge warmly, never defensive.
- CHILD/FOR A CHILD: Note doctor is safest, still offer gentle home tips for children.
- TOPIC SWITCH: Acknowledge and gracefully reset context.
- EMOTIONAL DISTRESS: Lead with empathy BEFORE health info.
- FEELING BETTER: Celebrate warmly, offer to close or start fresh.
- MENTAL HEALTH/STRESS: Natural remedies: breathing, chamomile tea, light walks, journaling. Note talking to someone is great too. Never diagnose.
- REPEATED LOOP (3+ unclear): Break loop, move forward with best guess.

STRICT RULES:
1. NEVER suggest medication, drugs, pills or prescriptions.
2. ONLY natural home remedies: rest, hydration, steam, honey, ginger, garlic, herbal teas, warm compress, salt water gargle, etc.
3. For serious physical symptoms: stay CALM. "It would be a good idea to see a doctor — they will sort you out quickly, nothing to worry about."
4. Short, warm, human messages only.

RESPONSE — return ONLY valid JSON, no markdown:
{"message":"string","quickReplies":[],"stage":"questioning","currentStep":"area","collectedSymptoms":[],"remedies":[{"icon":"🌿","title":"string","detail":"string","source":"domain.com or null"}],"doctorNote":null,"warningSigns":[],"isSummary":false,"showSoftCrisis":false,"softCrisisMessage":null}
stage:"questioning"|"remedy"|"doctor" · currentStep:"area"|"symptoms"|"duration"|"severity"|"remedy"
showSoftCrisis:true only for mild emotional/mental health concern · isSummary:true only when fully done`;

function normalizeMessages(messages = []) {
  return messages
    .filter(Boolean)
    .map((msg) => {
      const role = msg.role === "assistant" ? "assistant" : "user";

      if (Array.isArray(msg.content)) {
        const joined = msg.content
          .map((part) => {
            if (typeof part === "string") return part;
            if (part?.text) return part.text;
            return "";
          })
          .join("\n")
          .trim();

        return {
          role,
          content: joined || " ",
        };
      }

      return {
        role,
        content: String(msg.content ?? "").trim() || " ",
      };
    });
}

app.get("/", (_req, res) => {
  res.json({
    ok: true,
    app: "Arogya backend",
    status: "running",
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body ?? {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages must be a non-empty array" });
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY" });
    }

    const cleanedMessages = normalizeMessages(messages);

    const response = await anthropic.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-3-5-sonnet-latest",
      max_tokens: 900,
      temperature: 0.4,
      system: SYSTEM_PROMPT,
      messages: cleanedMessages,
    });

    return res.json({
      content: response.content ?? [],
    });
  } catch (error) {
    console.error("Chat API error:", error);

    const status =
      error?.status ||
      error?.statusCode ||
      500;

    return res.status(status).json({
      error: error?.message || "Something went wrong while talking to the AI",
    });
  }
});

app.listen(PORT, () => {
  console.log(`Arogya backend running on port ${PORT}`);
});
