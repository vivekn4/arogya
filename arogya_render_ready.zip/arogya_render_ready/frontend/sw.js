const CACHE = "arogya-v1";
const PRECACHE = ["./"];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(PRECACHE))
  );
});

self.addEventListener("fetch", event => {
  const url = event.request.url;

  if (url.includes("api.anthropic.com") || url.includes("railway.app")) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request))
  );
});
