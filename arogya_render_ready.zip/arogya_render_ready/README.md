# Arogya Render-ready package

## Folder structure

arogya_render_ready/
  frontend/
    index.html
    sw.js
  backend/
    arogya-server.js
    package.json
    .env.example

## What you need to change

### 1) Backend
In Render, deploy `backend` as a **Web Service**.

Settings:
- Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`

Add environment variables in Render:
- `ANTHROPIC_API_KEY`
- `ANTHROPIC_MODEL=claude-3-5-sonnet-latest`

### 2) Frontend
Deploy `frontend` as a **Static Site**.

Settings:
- Root Directory: `frontend`
- Build Command: leave blank
- Publish Directory: `.`

### 3) Connect frontend to backend
Open `frontend/index.html`

Find:
const BACKEND_URL = "https://YOUR-BACKEND-NAME.onrender.com/api/chat";

Replace it with your real backend URL from Render, for example:
const BACKEND_URL = "https://arogya-backend.onrender.com/api/chat";

Then push again so Render redeploys the frontend.

## Local notes
- Do not open the HTML using file://
- Use Live Server or host it normally
- `sw.js` must stay in the same frontend root folder

## Optional CORS tightening
If you get a CORS issue, replace:
app.use(cors());

with:
app.use(cors({
  origin: ["https://YOUR-FRONTEND-NAME.onrender.com"]
}));
